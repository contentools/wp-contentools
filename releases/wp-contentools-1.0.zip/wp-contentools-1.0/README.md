# WP Contentools plugin

This plugin enables the integration between the Contentools Platform and Wordpress.

### Features

- Allow X-Frame-Options
